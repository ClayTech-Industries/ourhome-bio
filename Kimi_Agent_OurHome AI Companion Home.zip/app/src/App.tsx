import { useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { useStore } from './store';
import { Scene3D } from './components/Scene3D';
import { ChatPanel } from './components/ChatPanel';
import { RoomNav } from './components/RoomNav';
import { InspectModal } from './components/InspectModal';
import { Onboarding } from './components/Onboarding';
import { RoomTransition } from './components/RoomTransition';
import './App.css';

function App() {
  const currentView = useStore((s) => s.currentView);
  const isOnboardingComplete = useStore((s) => s.isOnboardingComplete);
  const timeOfDay = useStore((s) => s.timeOfDay);
  
  // Update time of day periodically
  useEffect(() => {
    const interval = setInterval(() => {
      const hour = new Date().getHours();
      let newTime: typeof timeOfDay;
      if (hour < 10) newTime = 'morning';
      else if (hour < 16) newTime = 'afternoon';
      else if (hour < 20) newTime = 'evening';
      else newTime = 'night';
      useStore.getState().setTimeOfDay(newTime);
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="app-container">
      {/* 3D Canvas */}
      <div className="canvas-wrapper">
        <Canvas
          camera={{ position: [6, 4, 6], fov: 50, near: 0.1, far: 100 }}
          gl={{ antialias: true, alpha: false }}
          dpr={[1, 2]}
        >
          <Scene3D />
        </Canvas>
      </div>
      
      {/* Room Transition Overlay */}
      <RoomTransition />
      
      {/* UI Overlays */}
      {isOnboardingComplete && (
        <>
          <RoomNav />
          <ChatPanel />
        </>
      )}
      
      {/* Inspect Modal */}
      {currentView === 'inspect' && <InspectModal />}
      
      {/* Onboarding */}
      {!isOnboardingComplete && <Onboarding />}
    </div>
  );
}

export default App;
