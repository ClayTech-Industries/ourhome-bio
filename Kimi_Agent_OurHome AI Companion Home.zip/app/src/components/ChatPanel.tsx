import { useRef, useEffect, useCallback } from 'react';
import { useStore } from '../store';
import { parseIntent, generateNovaResponse } from '../lib/novaBrain';
import type { Message } from '../types';

export function ChatPanel() {
  const messages = useStore((s) => s.messages);
  const isNovaTyping = useStore((s) => s.isNovaTyping);
  const inputValue = useStore((s) => s.inputValue);
  const setInputValue = useStore((s) => s.setInputValue);
  const sendMessage = useStore((s) => s.sendMessage);
  const addMessage = useStore((s) => s.addMessage);
  const updateWallColor = useStore((s) => s.updateWallColor);
  const setCurrentRoom = useStore((s) => s.setCurrentRoom);
  const setNovaTyping = useStore((s) => s.setNovaTyping);
  const currentRoomId = useStore((s) => s.currentRoomId);
  const rooms = useStore((s) => s.rooms);
  const timeOfDay = useStore((s) => s.timeOfDay);
  const memoryObjects = useStore((s) => s.memoryObjects);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isNovaTyping]);
  
  // Handle Nova response
  useEffect(() => {
    if (!isNovaTyping) return;
    
    const lastUserMessage = [...messages].reverse().find((m) => m.sender === 'user');
    if (!lastUserMessage) {
      setNovaTyping(false);
      return;
    }
    
    const currentRoom = rooms.find((r) => r.id === currentRoomId);
    const nearbyObjects = memoryObjects
      .filter((o) => o.roomId === currentRoomId)
      .map((o) => o.type.replace('_', ' '));
    
    const intent = parseIntent(lastUserMessage.content);
    const { text, delay } = generateNovaResponse(lastUserMessage.content, intent, {
      currentRoom: currentRoomId,
      roomName: currentRoom?.name || 'this room',
      timeOfDay,
      nearbyObjects,
      messageHistory: messages.slice(-6).map((m) => m.content),
    });
    
    // Handle intent actions
    const timer = setTimeout(() => {
      // Execute environment changes
      if (intent.action === 'change_wall_color' && intent.value) {
        const wallId = intent.target || 'north';
        updateWallColor(currentRoomId, wallId, intent.value);
      }
      
      if (intent.action === 'navigate_room' && intent.target) {
        setCurrentRoom(intent.target);
      }
      
      const novaMsg: Message = {
        id: `msg_${Date.now()}`,
        sender: 'nova',
        content: text,
        timestamp: new Date(),
      };
      
      addMessage(novaMsg);
    }, delay);
    
    return () => clearTimeout(timer);
  }, [isNovaTyping]);
  
  const handleSubmit = useCallback(() => {
    if (!inputValue.trim()) return;
    sendMessage(inputValue.trim());
  }, [inputValue, sendMessage]);
  
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  }, [handleSubmit]);
  
  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat('en', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    }).format(date);
  };
  
  return (
    <div 
      className="chat-panel"
      style={{
        position: 'absolute',
        bottom: '24px',
        left: '24px',
        width: '420px',
        maxHeight: '60vh',
        background: 'rgba(26, 20, 16, 0.85)',
        backdropFilter: 'blur(16px)',
        border: '1px solid rgba(245, 240, 232, 0.08)',
        borderRadius: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        zIndex: 20,
        animation: 'fadeInUp 0.5s ease-out',
      }}
    >
      {/* Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        marginBottom: '12px',
        paddingBottom: '10px',
        borderBottom: '1px solid rgba(245, 240, 232, 0.06)',
      }}>
        <div style={{
          width: '8px',
          height: '8px',
          borderRadius: '50%',
          background: '#d4a574',
          boxShadow: '0 0 8px rgba(212, 165, 116, 0.5)',
          animation: 'pulse 2s ease-in-out infinite',
        }} />
        <span style={{
          fontSize: '0.8125rem',
          color: '#a3988a',
          fontWeight: 500,
          letterSpacing: '0.02em',
        }}>
          Nova
        </span>
        <span style={{
          fontSize: '0.6875rem',
          color: 'rgba(163, 152, 138, 0.5)',
          marginLeft: 'auto',
        }}>
          {useStore.getState().rooms.find((r) => r.id === currentRoomId)?.name}
        </span>
      </div>
      
      {/* Messages Area */}
      <div style={{
        flex: 1,
        overflowY: 'auto',
        display: 'flex',
        flexDirection: 'column',
        gap: '6px',
        paddingBottom: '8px',
        minHeight: '120px',
        maxHeight: '40vh',
      }}>
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={msg.sender === 'nova' ? 'message-nova' : 'message-user'}
            style={{
              alignSelf: msg.sender === 'user' ? 'flex-end' : 'flex-start',
              maxWidth: '85%',
              background: msg.sender === 'nova' 
                ? 'rgba(212, 165, 116, 0.12)' 
                : 'rgba(245, 240, 232, 0.06)',
              border: msg.sender === 'nova'
                ? '1px solid rgba(212, 165, 116, 0.2)'
                : '1px solid rgba(245, 240, 232, 0.1)',
              borderRadius: msg.sender === 'nova' 
                ? '16px 16px 16px 4px' 
                : '16px 16px 4px 16px',
              padding: '10px 14px',
              color: '#f5f0e8',
              fontSize: '0.9375rem',
              lineHeight: 1.5,
              wordBreak: 'break-word',
              animation: msg.sender === 'nova' 
                ? 'fadeInUp 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards'
                : 'fadeInUp 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards',
            }}
          >
            <div>{msg.content}</div>
            <div style={{
              fontSize: '0.6875rem',
              color: 'rgba(245, 240, 232, 0.35)',
              marginTop: '4px',
              textAlign: msg.sender === 'user' ? 'right' : 'left',
            }}>
              {formatTime(msg.timestamp)}
            </div>
          </div>
        ))}
        
        {/* Typing Indicator */}
        {isNovaTyping && (
          <div
            style={{
              alignSelf: 'flex-start',
              background: 'rgba(212, 165, 116, 0.08)',
              border: '1px solid rgba(212, 165, 116, 0.15)',
              borderRadius: '16px 16px 16px 4px',
              padding: '12px 16px',
              animation: 'fadeInUp 0.3s ease-out',
            }}
          >
            <div className="typing-indicator">
              <span />
              <span />
              <span />
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      {/* Input Area */}
      <div style={{
        borderTop: '1px solid rgba(245, 240, 232, 0.08)',
        paddingTop: '12px',
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
      }}>
        <input
          ref={inputRef}
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Say something to Nova..."
          style={{
            flex: 1,
            background: 'transparent',
            border: 'none',
            outline: 'none',
            color: '#f5f0e8',
            fontSize: '0.9375rem',
            padding: '6px 0',
            caretColor: '#d4a574',
          }}
        />
        <button
          onClick={handleSubmit}
          disabled={!inputValue.trim()}
          style={{
            background: inputValue.trim() ? 'rgba(212, 165, 116, 0.2)' : 'transparent',
            border: inputValue.trim() ? '1px solid rgba(212, 165, 116, 0.3)' : '1px solid transparent',
            borderRadius: '50%',
            width: '36px',
            height: '36px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: inputValue.trim() ? 'pointer' : 'default',
            color: inputValue.trim() ? '#d4a574' : 'rgba(245, 240, 232, 0.25)',
            transition: 'all 0.2s ease',
            fontSize: '1rem',
          }}
        >
          ↑
        </button>
      </div>
    </div>
  );
}
