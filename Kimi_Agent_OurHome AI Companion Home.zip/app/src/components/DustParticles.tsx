import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import type { TimeOfDay } from '../types';

interface DustParticlesProps {
  count: number;
  timeOfDay: TimeOfDay;
}

export function DustParticles({ count, timeOfDay }: DustParticlesProps) {
  const pointsRef = useRef<THREE.Points>(null);
  
  const particleColor = useMemo(() => {
    switch (timeOfDay) {
      case 'morning': return '#FFF5E4';
      case 'afternoon': return '#FFD580';
      case 'evening': return '#FF9B6A';
      case 'night': return '#4A5A8A';
    }
  }, [timeOfDay]);
  
  // Generate particle positions and velocities
  const { positions, velocities } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);
    
    for (let i = 0; i < count; i++) {
      // Spread particles throughout the room
      positions[i * 3] = (Math.random() - 0.5) * 8;     // x
      positions[i * 3 + 1] = Math.random() * 3.5;        // y
      positions[i * 3 + 2] = (Math.random() - 0.5) * 6;  // z
      
      // Very slow drift velocities
      velocities[i * 3] = (Math.random() - 0.5) * 0.002;
      velocities[i * 3 + 1] = Math.random() * 0.001 + 0.0005; // slight upward drift
      velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.002;
    }
    
    return { positions, velocities };
  }, [count]);
  
  useFrame(() => {
    if (!pointsRef.current) return;
    
    const posArray = pointsRef.current.geometry.attributes.position.array as Float32Array;
    
    for (let i = 0; i < count; i++) {
      // Update positions
      posArray[i * 3] += velocities[i * 3];
      posArray[i * 3 + 1] += velocities[i * 3 + 1];
      posArray[i * 3 + 2] += velocities[i * 3 + 2];
      
      // Brownian motion jitter
      posArray[i * 3] += (Math.random() - 0.5) * 0.001;
      posArray[i * 3 + 2] += (Math.random() - 0.5) * 0.001;
      
      // Wrap around boundaries
      if (posArray[i * 3 + 1] > 3.5) posArray[i * 3 + 1] = 0;
      if (posArray[i * 3] > 4) posArray[i * 3] = -4;
      if (posArray[i * 3] < -4) posArray[i * 3] = 4;
      if (posArray[i * 3 + 2] > 3) posArray[i * 3 + 2] = -3;
      if (posArray[i * 3 + 2] < -3) posArray[i * 3 + 2] = 3;
    }
    
    pointsRef.current.geometry.attributes.position.needsUpdate = true;
  });
  
  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        color={particleColor}
        size={0.03}
        transparent
        opacity={0.35}
        sizeAttenuation
        depthWrite={false}
      />
    </points>
  );
}
