import * as THREE from 'three';
import type { FurnitureItem } from '../types';

interface Furniture3DProps {
  item: FurnitureItem;
}

export function Furniture3D({ item }: Furniture3DProps) {
  const { type, position, rotation, color } = item;
  
  return (
    <group 
      position={[position.x, position.y, position.z]} 
      rotation={[0, rotation, 0]}
    >
      {type === 'couch' && <Couch color={color} />}
      {type === 'table' && <Table color={color} />}
      {type === 'lamp' && <Lamp color={color} />}
      {type === 'bookshelf' && <Bookshelf color={color} />}
      {type === 'bed' && <Bed color={color} />}
      {type === 'plant' && <Plant color={color} />}
    </group>
  );
}

function Couch({ color }: { color: string }) {
  return (
    <group>
      {/* Main seat */}
      <mesh position={[0, 0.35, 0]} castShadow receiveShadow>
        <boxGeometry args={[2.2, 0.35, 0.9]} />
        <meshStandardMaterial color={color} roughness={0.9} />
      </mesh>
      
      {/* Backrest */}
      <mesh position={[0, 0.7, -0.35]} castShadow>
        <boxGeometry args={[2.2, 0.7, 0.2]} />
        <meshStandardMaterial color={color} roughness={0.9} />
      </mesh>
      
      {/* Left armrest */}
      <mesh position={[-1, 0.45, 0]} castShadow>
        <boxGeometry args={[0.25, 0.5, 0.9]} />
        <meshStandardMaterial color={darkenColor(color, 0.1)} roughness={0.9} />
      </mesh>
      
      {/* Right armrest */}
      <mesh position={[1, 0.45, 0]} castShadow>
        <boxGeometry args={[0.25, 0.5, 0.9]} />
        <meshStandardMaterial color={darkenColor(color, 0.1)} roughness={0.9} />
      </mesh>
      
      {/* Seat cushion line */}
      <mesh position={[0, 0.53, 0.01]}>
        <boxGeometry args={[1.5, 0.02, 0.85]} />
        <meshStandardMaterial color={lightenColor(color, 0.05)} roughness={0.95} />
      </mesh>
      
      {/* Legs */}
      {[[-0.9, -0.35], [0.9, -0.35], [-0.9, 0.35], [0.9, 0.35]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.08, z]} castShadow>
          <cylinderGeometry args={[0.04, 0.04, 0.16, 8]} />
          <meshStandardMaterial color="#3a2a1a" roughness={0.8} />
        </mesh>
      ))}
    </group>
  );
}

function Table({ color }: { color: string }) {
  return (
    <group>
      {/* Table top */}
      <mesh position={[0, 0.7, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[0.8, 0.8, 0.06, 16]} />
        <meshStandardMaterial color={color} roughness={0.6} metalness={0.1} />
      </mesh>
      
      {/* Central leg */}
      <mesh position={[0, 0.35, 0]} castShadow>
        <cylinderGeometry args={[0.06, 0.08, 0.7, 8]} />
        <meshStandardMaterial color={darkenColor(color, 0.15)} roughness={0.5} metalness={0.15} />
      </mesh>
      
      {/* Base */}
      <mesh position={[0, 0.02, 0]} castShadow>
        <cylinderGeometry args={[0.4, 0.45, 0.04, 12]} />
        <meshStandardMaterial color={darkenColor(color, 0.1)} roughness={0.5} metalness={0.1} />
      </mesh>
    </group>
  );
}

function Lamp({ color }: { color: string }) {
  return (
    <group>
      {/* Base */}
      <mesh position={[0, 0.05, 0]} castShadow>
        <cylinderGeometry args={[0.2, 0.22, 0.1, 12]} />
        <meshStandardMaterial color={darkenColor(color, 0.2)} roughness={0.4} metalness={0.3} />
      </mesh>
      
      {/* Pole */}
      <mesh position={[0, 0.8, 0]} castShadow>
        <cylinderGeometry args={[0.025, 0.03, 1.5, 8]} />
        <meshStandardMaterial color={darkenColor(color, 0.1)} roughness={0.4} metalness={0.2} />
      </mesh>
      
      {/* Shade */}
      <mesh position={[0, 1.6, 0]}>
        <cylinderGeometry args={[0.15, 0.3, 0.35, 12, 1, true]} />
        <meshStandardMaterial 
          color={color} 
          roughness={0.8} 
          transparent 
          opacity={0.85}
          side={THREE.DoubleSide}
        />
      </mesh>
      
      {/* Light bulb glow */}
      <pointLight
        color="#FFD580"
        intensity={0.6}
        distance={5}
        decay={2}
        position={[0, 1.5, 0]}
      />
    </group>
  );
}

function Bookshelf({ color }: { color: string }) {
  const shelfWidth = 1.8;
  const shelfHeight = 2.2;
  const shelfDepth = 0.35;
  
  return (
    <group>
      {/* Back panel */}
      <mesh position={[0, shelfHeight / 2, -shelfDepth / 2 + 0.02]}>
        <boxGeometry args={[shelfWidth, shelfHeight, 0.03]} />
        <meshStandardMaterial color={color} roughness={0.8} />
      </mesh>
      
      {/* Side panels */}
      <mesh position={[-shelfWidth / 2 + 0.02, shelfHeight / 2, 0]}>
        <boxGeometry args={[0.04, shelfHeight, shelfDepth]} />
        <meshStandardMaterial color={color} roughness={0.8} />
      </mesh>
      <mesh position={[shelfWidth / 2 - 0.02, shelfHeight / 2, 0]}>
        <boxGeometry args={[0.04, shelfHeight, shelfDepth]} />
        <meshStandardMaterial color={color} roughness={0.8} />
      </mesh>
      
      {/* Shelves */}
      {[0, 0.25, 0.5, 0.75, 1.0].map((f, i) => (
        <mesh key={i} position={[0, f * shelfHeight + 0.02, 0]}>
          <boxGeometry args={[shelfWidth - 0.04, 0.03, shelfDepth]} />
          <meshStandardMaterial color={lightenColor(color, 0.05)} roughness={0.8} />
        </mesh>
      ))}
      
      {/* Books on shelves */}
      {[0.3, 0.55, 0.8].map((fy, shelfIdx) =>
        [0, 1, 2, 3, 4].map((bx) => {
          const bookColors = ['#8B4513', '#2F4F4F', '#800020', '#4A6741', '#6B4C3B', '#5B4A3C'];
          const bColor = bookColors[(bx + shelfIdx * 2) % bookColors.length];
          const bHeight = 0.15 + Math.random() * 0.1;
          return (
            <mesh 
              key={`${shelfIdx}-${bx}`} 
              position={[-0.6 + bx * 0.3, fy * shelfHeight + 0.02 + bHeight / 2, 0]}
            >
              <boxGeometry args={[0.08, bHeight, 0.25]} />
              <meshStandardMaterial color={bColor} roughness={0.7} />
            </mesh>
          );
        })
      )}
    </group>
  );
}

function Bed({ color }: { color: string }) {
  return (
    <group>
      {/* Bed frame */}
      <mesh position={[0, 0.25, 0]} castShadow receiveShadow>
        <boxGeometry args={[1.6, 0.2, 2.2]} />
        <meshStandardMaterial color={darkenColor(color, 0.2)} roughness={0.8} />
      </mesh>
      
      {/* Mattress */}
      <mesh position={[0, 0.4, 0]} castShadow>
        <boxGeometry args={[1.5, 0.15, 2.1]} />
        <meshStandardMaterial color={color} roughness={0.95} />
      </mesh>
      
      {/* Headboard */}
      <mesh position={[0, 0.8, -1.0]} castShadow>
        <boxGeometry args={[1.6, 1.0, 0.08]} />
        <meshStandardMaterial color={darkenColor(color, 0.15)} roughness={0.8} />
      </mesh>
      
      {/* Pillow */}
      <mesh position={[0, 0.55, -0.7]}>
        <boxGeometry args={[1.0, 0.12, 0.5]} />
        <meshStandardMaterial color="#ffffff" roughness={0.95} />
      </mesh>
      
      {/* Blanket */}
      <mesh position={[0, 0.52, 0.3]}>
        <boxGeometry args={[1.45, 0.08, 1.2]} />
        <meshStandardMaterial color={lightenColor(color, 0.1)} roughness={0.95} />
      </mesh>
    </group>
  );
}

function Plant({ color }: { color: string }) {
  return (
    <group>
      {/* Pot */}
      <mesh position={[0, 0.2, 0]} castShadow>
        <cylinderGeometry args={[0.2, 0.15, 0.4, 12]} />
        <meshStandardMaterial color="#C4A882" roughness={0.7} />
      </mesh>
      
      {/* Soil */}
      <mesh position={[0, 0.38, 0]}>
        <cylinderGeometry args={[0.18, 0.18, 0.04, 12]} />
        <meshStandardMaterial color="#3a2410" roughness={0.95} />
      </mesh>
      
      {/* Stem */}
      <mesh position={[0, 0.6, 0]}>
        <cylinderGeometry args={[0.02, 0.025, 0.5, 8]} />
        <meshStandardMaterial color={darkenColor(color, 0.2)} roughness={0.8} />
      </mesh>
      
      {/* Leaves */}
      {[0, 1, 2, 3, 4].map((i) => {
        const angle = (i / 5) * Math.PI * 2;
        const y = 0.6 + Math.random() * 0.3;
        const r = 0.15 + Math.random() * 0.1;
        return (
          <mesh 
            key={i} 
            position={[Math.cos(angle) * r * 0.5, y, Math.sin(angle) * r * 0.5]}
            rotation={[Math.random() * 0.5, angle, Math.random() * 0.3]}
          >
            <sphereGeometry args={[0.12, 8, 6]} />
            <meshStandardMaterial color={color} roughness={0.8} />
          </mesh>
        );
      })}
    </group>
  );
}

// Color helpers
function darkenColor(hex: string, amount: number): string {
  const color = new THREE.Color(hex);
  color.r = Math.max(0, color.r - amount);
  color.g = Math.max(0, color.g - amount);
  color.b = Math.max(0, color.b - amount);
  return `#${color.getHexString()}`;
}

function lightenColor(hex: string, amount: number): string {
  const color = new THREE.Color(hex);
  color.r = Math.min(1, color.r + amount);
  color.g = Math.min(1, color.g + amount);
  color.b = Math.min(1, color.b + amount);
  return `#${color.getHexString()}`;
}
