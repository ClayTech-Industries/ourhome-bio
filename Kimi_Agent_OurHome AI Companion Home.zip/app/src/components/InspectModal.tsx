import { useStore } from '../store';
import { useEffect } from 'react';

export function InspectModal() {
  const activeMemoryId = useStore((s) => s.activeMemoryId);
  const memories = useStore((s) => s.memories);
  const setActiveMemory = useStore((s) => s.setActiveMemory);
  const currentView = useStore((s) => s.currentView);
  
  const memory = memories.find((m) => m.id === activeMemoryId);
  
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setActiveMemory(null);
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [setActiveMemory]);
  
  if (!memory || currentView !== 'inspect') return null;
  
  const getPatinaDescription = (level: number) => {
    if (level < 0.2) return 'This memory is still fresh, the edges sharp.';
    if (level < 0.5) return 'Time has softened this one, like a well-worn photograph.';
    if (level < 0.8) return 'Aged and warm, the way all good memories become.';
    return 'Ancient now, but the feeling remains untouched.';
  };
  
  const getEmotionalLabel = (valence: number) => {
    if (valence > 0.6) return 'Joy';
    if (valence > 0.2) return 'Warmth';
    if (valence > -0.2) return 'Quiet';
    if (valence > -0.6) return 'Melancholy';
    return 'Longing';
  };
  
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(date);
  };
  
  return (
    <div
      onClick={() => setActiveMemory(null)}
      style={{
        position: 'absolute',
        inset: 0,
        zIndex: 50,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'rgba(26, 20, 16, 0.6)',
        backdropFilter: 'blur(4px)',
        animation: 'fadeIn 0.3s ease-out',
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: 'rgba(26, 20, 16, 0.95)',
          backdropFilter: 'blur(20px)',
          border: '1px solid rgba(212, 165, 116, 0.25)',
          borderRadius: '20px',
          padding: '32px',
          maxWidth: '440px',
          width: '90%',
          maxHeight: '80vh',
          overflowY: 'auto',
          animation: 'scaleIn 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
          position: 'relative',
        }}
      >
        {/* Close button */}
        <button
          onClick={() => setActiveMemory(null)}
          style={{
            position: 'absolute',
            top: '16px',
            right: '16px',
            background: 'transparent',
            border: 'none',
            color: 'rgba(245, 240, 232, 0.5)',
            fontSize: '1.25rem',
            cursor: 'pointer',
            width: '32px',
            height: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: '50%',
            transition: 'all 0.2s',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(245, 240, 232, 0.08)';
            e.currentTarget.style.color = '#f5f0e8';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.color = 'rgba(245, 240, 232, 0.5)';
          }}
        >
          ×
        </button>
        
        {/* Memory Image */}
        {memory.imageUrl && (
          <div style={{
            width: '100%',
            aspectRatio: '4/3',
            borderRadius: '12px',
            overflow: 'hidden',
            marginBottom: '20px',
            border: '1px solid rgba(212, 165, 116, 0.15)',
          }}>
            <img
              src={memory.imageUrl}
              alt={memory.title}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
              }}
            />
          </div>
        )}
        
        {/* Title */}
        <h2 style={{
          fontSize: '1.5rem',
          fontWeight: 500,
          color: '#f5f0e8',
          marginBottom: '4px',
          letterSpacing: '-0.01em',
        }}>
          {memory.title}
        </h2>
        
        {/* Date */}
        <p style={{
          fontSize: '0.8125rem',
          color: 'rgba(163, 152, 138, 0.7)',
          marginBottom: '16px',
        }}>
          {formatDate(memory.createdAt)}
        </p>
        
        {/* Content */}
        <p style={{
          fontSize: '0.9375rem',
          color: 'rgba(245, 240, 232, 0.85)',
          lineHeight: 1.7,
          marginBottom: '20px',
        }}>
          {memory.content}
        </p>
        
        {/* Nova's Recall */}
        {memory.novaRecall && (
          <div style={{
            borderLeft: '2px solid #d4a574',
            paddingLeft: '16px',
            marginBottom: '20px',
          }}>
            <p style={{
              fontSize: '0.9375rem',
              color: '#d4a574',
              fontStyle: 'italic',
              lineHeight: 1.7,
            }}>
              "{memory.novaRecall}"
            </p>
            <p style={{
              fontSize: '0.75rem',
              color: 'rgba(212, 165, 116, 0.6)',
              marginTop: '8px',
            }}>
              — Nova
            </p>
          </div>
        )}
        
        {/* Metadata */}
        <div style={{
          display: 'flex',
          gap: '16px',
          paddingTop: '16px',
          borderTop: '1px solid rgba(245, 240, 232, 0.06)',
        }}>
          <MetadataPill 
            label="Feeling" 
            value={getEmotionalLabel(memory.emotionalValence)} 
          />
          <MetadataPill 
            label="Visits" 
            value={`${memory.accessCount} time${memory.accessCount !== 1 ? 's' : ''}`} 
          />
          <MetadataPill 
            label="Age" 
            value={getPatinaDescription(memory.patinaLevel)} 
            small
          />
        </div>
      </div>
    </div>
  );
}

function MetadataPill({ label, value, small }: { label: string; value: string; small?: boolean }) {
  return (
    <div style={{ flex: small ? 2 : 1 }}>
      <p style={{
        fontSize: '0.6875rem',
        color: 'rgba(163, 152, 138, 0.6)',
        textTransform: 'uppercase',
        letterSpacing: '0.05em',
        marginBottom: '2px',
      }}>
        {label}
      </p>
      <p style={{
        fontSize: small ? '0.75rem' : '0.8125rem',
        color: 'rgba(245, 240, 232, 0.7)',
        lineHeight: 1.4,
      }}>
        {value}
      </p>
    </div>
  );
}
