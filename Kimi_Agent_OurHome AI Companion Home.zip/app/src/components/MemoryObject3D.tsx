import { useRef, useState, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useLoader } from '@react-three/fiber';
import { TextureLoader } from 'three';
import * as THREE from 'three';
import type { MemoryObject } from '../types';
import { useStore } from '../store';

interface MemoryObject3DProps {
  obj: MemoryObject;
}

export function MemoryObject3D({ obj }: MemoryObject3DProps) {
  const groupRef = useRef<THREE.Group>(null);
  const glowRef = useRef<THREE.PointLight>(null);
  const [hovered, setHovered] = useState(false);
  const inspectMemoryObject = useStore((s) => s.inspectMemoryObject);
  const currentRoomId = useStore((s) => s.currentRoomId);
  
  // Only show objects for current room
  if (obj.roomId !== currentRoomId) return null;
  
  const handleClick = (e: { stopPropagation: () => void }) => {
    e.stopPropagation();
    inspectMemoryObject(obj.id);
  };
  
  // Idle animation - subtle pulse and float
  useFrame((state) => {
    if (!groupRef.current) return;
    
    const t = state.clock.elapsedTime;
    const baseY = obj.position.y;
    
    // Very subtle float
    groupRef.current.position.y = baseY + Math.sin(t * 0.8 + obj.position.x) * 0.015;
    
    // Glow pulse
    if (glowRef.current) {
      const pulseIntensity = obj.glowIntensity + Math.sin(t * 1.5 + obj.position.z) * 0.08;
      glowRef.current.intensity = hovered ? pulseIntensity * 2 : pulseIntensity;
    }
    
    // Hover scale
    const targetScale = hovered ? obj.scale * 1.08 : obj.scale;
    groupRef.current.scale.lerp(
      new THREE.Vector3(targetScale, targetScale, targetScale),
      0.1
    );
  });
  
  return (
    <group
      ref={groupRef}
      position={[obj.position.x, obj.position.y, obj.position.z]}
      rotation={[0, obj.rotation, 0]}
      scale={obj.scale}
      onClick={handleClick}
      onPointerOver={() => { setHovered(true); document.body.style.cursor = 'pointer'; }}
      onPointerOut={() => { setHovered(false); document.body.style.cursor = 'auto'; }}
    >
      {/* Glow light */}
      <pointLight
        ref={glowRef}
        color="#d4a574"
        intensity={obj.glowIntensity}
        distance={3}
        decay={2}
      />
      
      {/* Object geometry based on type */}
      {obj.type === 'photo_frame' && <PhotoFrame hovered={hovered} memoryId={obj.memoryId} />}
      {obj.type === 'book' && <Book hovered={hovered} />}
      {obj.type === 'post_it' && <PostIt hovered={hovered} />}
      {obj.type === 'vase' && <Vase hovered={hovered} />}
      {obj.type === 'souvenir' && <Souvenir hovered={hovered} />}
    </group>
  );
}

// Photo Frame Component
function PhotoFrame({ hovered, memoryId }: { hovered: boolean; memoryId: string }) {
  const memories = useStore((s) => s.memories);
  const memory = memories.find((m) => m.id === memoryId);
  const imageUrl = memory?.imageUrl;
  
  let texture: THREE.Texture | null = null;
  try {
    if (imageUrl) {
      texture = useLoader(TextureLoader, imageUrl);
    }
  } catch {
    // Texture not loaded yet
  }
  
  const frameColor = '#5c4033';
  const frameWidth = 0.6;
  const frameHeight = 0.8;
  const frameDepth = 0.05;
  const borderWidth = 0.06;
  
  return (
    <group>
      {/* Frame backing */}
      <mesh position={[0, 0, -frameDepth / 2]}>
        <boxGeometry args={[frameWidth, frameHeight, frameDepth]} />
        <meshStandardMaterial color={frameColor} roughness={0.7} />
      </mesh>
      
      {/* Photo/image area */}
      <mesh position={[0, 0, frameDepth / 2 + 0.001]}>
        <planeGeometry args={[frameWidth - borderWidth * 2, frameHeight - borderWidth * 2]} />
        {texture ? (
          <meshStandardMaterial map={texture} roughness={0.5} />
        ) : (
          <meshStandardMaterial 
            color={hovered ? '#d4a574' : '#c4a882'} 
            roughness={0.6} 
          />
        )}
      </mesh>
      
      {/* Frame border top */}
      <mesh position={[0, frameHeight / 2 - borderWidth / 2, frameDepth / 2]}>
        <boxGeometry args={[frameWidth, borderWidth, frameDepth * 0.5]} />
        <meshStandardMaterial color={frameColor} roughness={0.6} />
      </mesh>
      
      {/* Frame border bottom */}
      <mesh position={[0, -frameHeight / 2 + borderWidth / 2, frameDepth / 2]}>
        <boxGeometry args={[frameWidth, borderWidth, frameDepth * 0.5]} />
        <meshStandardMaterial color={frameColor} roughness={0.6} />
      </mesh>
      
      {/* Frame border left */}
      <mesh position={[-frameWidth / 2 + borderWidth / 2, 0, frameDepth / 2]}>
        <boxGeometry args={[borderWidth, frameHeight - borderWidth * 2, frameDepth * 0.5]} />
        <meshStandardMaterial color={frameColor} roughness={0.6} />
      </mesh>
      
      {/* Frame border right */}
      <mesh position={[frameWidth / 2 - borderWidth / 2, 0, frameDepth / 2]}>
        <boxGeometry args={[borderWidth, frameHeight - borderWidth * 2, frameDepth * 0.5]} />
        <meshStandardMaterial color={frameColor} roughness={0.6} />
      </mesh>
      
      {/* Stand at back */}
      <mesh position={[0, -0.1, -frameDepth - 0.08]} rotation={[0.3, 0, 0]}>
        <boxGeometry args={[0.15, 0.02, 0.15]} />
        <meshStandardMaterial color={frameColor} roughness={0.8} />
      </mesh>
    </group>
  );
}

// Book Component
function Book({ hovered }: { hovered: boolean }) {
  const coverColor = useMemo(() => {
    const colors = ['#8B4513', '#2F4F4F', '#800020', '#4A6741', '#6B4C3B'];
    return colors[Math.floor(Math.random() * colors.length)];
  }, []);
  
  return (
    <group>
      {/* Book cover */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[0.35, 0.5, 0.08]} />
        <meshStandardMaterial 
          color={hovered ? '#d4a574' : coverColor} 
          roughness={0.7} 
        />
      </mesh>
      
      {/* Pages (lighter strip on right edge) */}
      <mesh position={[0.16, 0, 0]}>
        <boxGeometry args={[0.03, 0.46, 0.075]} />
        <meshStandardMaterial color="#f5f0e8" roughness={0.9} />
      </mesh>
      
      {/* Spine */}
      <mesh position={[-0.16, 0, 0]}>
        <boxGeometry args={[0.03, 0.5, 0.08]} />
        <meshStandardMaterial color={coverColor} roughness={0.6} metalness={0.1} />
      </mesh>
    </group>
  );
}

// Post-It Note Component
function PostIt({ hovered }: { hovered: boolean }) {
  return (
    <group>
      <mesh>
        <planeGeometry args={[0.25, 0.25]} />
        <meshStandardMaterial 
          color={hovered ? '#FFE66D' : '#F5E6A3'} 
          roughness={0.9}
          side={THREE.DoubleSide}
        />
      </mesh>
      
      {/* Subtle shadow underneath */}
      <mesh position={[0.01, -0.01, -0.001]}>
        <planeGeometry args={[0.25, 0.25]} />
        <meshStandardMaterial 
          color="#000000" 
          transparent 
          opacity={0.15} 
          side={THREE.DoubleSide}
        />
      </mesh>
    </group>
  );
}

// Vase Component
function Vase({ hovered }: { hovered: boolean }) {
  const points = useMemo(() => {
    const pts: THREE.Vector2[] = [];
    // Create a simple vase profile using lathe
    pts.push(new THREE.Vector2(0, 0));
    pts.push(new THREE.Vector2(0.15, 0));
    pts.push(new THREE.Vector2(0.18, 0.05));
    pts.push(new THREE.Vector2(0.16, 0.15));
    pts.push(new THREE.Vector2(0.12, 0.3));
    pts.push(new THREE.Vector2(0.1, 0.45));
    pts.push(new THREE.Vector2(0.11, 0.5));
    pts.push(new THREE.Vector2(0.13, 0.55));
    pts.push(new THREE.Vector2(0.1, 0.6));
    return pts;
  }, []);
  
  return (
    <group>
      <mesh>
        <latheGeometry args={[points, 16]} />
        <meshStandardMaterial 
          color={hovered ? '#d4a574' : '#C4A882'} 
          roughness={0.4} 
          metalness={0.1}
        />
      </mesh>
    </group>
  );
}

// Souvenir Component (small decorative item)
function Souvenir({ hovered }: { hovered: boolean }) {
  return (
    <group>
      {/* Small decorative box */}
      <mesh position={[0, 0.1, 0]}>
        <boxGeometry args={[0.2, 0.2, 0.2]} />
        <meshStandardMaterial 
          color={hovered ? '#d4a574' : '#8B7355'} 
          roughness={0.5} 
          metalness={0.2}
        />
      </mesh>
      
      {/* Lid */}
      <mesh position={[0, 0.21, 0]}>
        <boxGeometry args={[0.22, 0.03, 0.22]} />
        <meshStandardMaterial 
          color={hovered ? '#E8C89A' : '#A08060'} 
          roughness={0.4} 
        />
      </mesh>
    </group>
  );
}
