import { useState, useEffect, useRef, useCallback } from 'react';
import { useStore } from '../store';

export function Onboarding() {
  const [step, setStep] = useState(0);
  const [inputValue, setInputValue] = useState('');
  const [isComplete, setIsComplete] = useState(false);
  const [showCursor, setShowCursor] = useState(true);
  const completeOnboarding = useStore((s) => s.completeOnboarding);
  const updateWallColor = useStore((s) => s.updateWallColor);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Progress through steps with CSS timing
  useEffect(() => {
    // After "You're here." animation completes (12 chars * 0.08s = ~1s + delay)
    const t1 = setTimeout(() => setShowCursor(false), 1400);
    const t2 = setTimeout(() => setStep(1), 2000);
    
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);
  
  // Auto-focus input on step 1
  useEffect(() => {
    if (step === 1) {
      setTimeout(() => inputRef.current?.focus(), 500);
    }
  }, [step]);
  
  const handleSubmit = useCallback(() => {
    if (!inputValue.trim()) return;
    
    const feeling = inputValue.toLowerCase();
    let firstColor = '#f5f0e8';
    
    if (feeling.includes('warm') || feeling.includes('cozy') || feeling.includes('safe')) {
      firstColor = '#C4663C';
    } else if (feeling.includes('calm') || feeling.includes('peace') || feeling.includes('quiet')) {
      firstColor = '#8a9a7a';
    } else if (feeling.includes('bright') || feeling.includes('happy') || feeling.includes('light')) {
      firstColor = '#FFD580';
    } else if (feeling.includes('soft') || feeling.includes('gentle')) {
      firstColor = '#E8D5C4';
    } else if (feeling.includes('deep') || feeling.includes('rich')) {
      firstColor = '#6b5b73';
    }
    
    updateWallColor('living_room', 'north', firstColor);
    setIsComplete(true);
    setTimeout(() => completeOnboarding(), 1500);
  }, [inputValue, completeOnboarding, updateWallColor]);
  
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSubmit();
  }, [handleSubmit]);
  
  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        zIndex: 100,
        background: isComplete ? 'transparent' : 'rgba(26, 20, 16, 0.95)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'background 1.5s ease-out, opacity 1s ease-out',
        opacity: isComplete ? 0 : 1,
        pointerEvents: isComplete ? 'none' : 'auto',
      }}
    >
      {step === 0 && (
        <div style={{ textAlign: 'center', animation: 'fadeIn 1s ease-out' }}>
          <h1 style={{
            fontSize: '2.5rem',
            fontWeight: 300,
            color: '#f5f0e8',
            letterSpacing: '-0.02em',
          }}>
            <span className="typewriter-text">You're here.</span>
            {showCursor && (
              <span style={{ color: '#d4a574', animation: 'blink 1s step-end infinite' }}>|</span>
            )}
          </h1>
        </div>
      )}
      
      {step === 1 && (
        <div style={{
          textAlign: 'center',
          animation: 'fadeInUp 0.8s ease-out',
          width: '100%',
          maxWidth: '500px',
          padding: '0 24px',
        }}>
          <h2 style={{
            fontSize: '1.75rem',
            fontWeight: 300,
            color: '#f5f0e8',
            letterSpacing: '-0.01em',
            marginBottom: '40px',
            lineHeight: 1.4,
          }}>
            What do you want this to feel like?
          </h2>
          
          <div style={{ position: 'relative', width: '100%' }}>
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Like warm afternoon light..."
              style={{
                width: '100%',
                background: 'rgba(245, 240, 232, 0.05)',
                border: '1px solid rgba(245, 240, 232, 0.15)',
                borderRadius: '16px',
                padding: '16px 24px',
                color: '#f5f0e8',
                fontSize: '1rem',
                outline: 'none',
                caretColor: '#d4a574',
                textAlign: 'center',
                transition: 'all 0.3s ease',
              }}
              onFocus={(e) => {
                e.currentTarget.style.borderColor = 'rgba(212, 165, 116, 0.4)';
                e.currentTarget.style.background = 'rgba(245, 240, 232, 0.08)';
              }}
              onBlur={(e) => {
                e.currentTarget.style.borderColor = 'rgba(245, 240, 232, 0.15)';
                e.currentTarget.style.background = 'rgba(245, 240, 232, 0.05)';
              }}
            />
            
            {inputValue.trim() && (
              <button
                onClick={handleSubmit}
                style={{
                  position: 'absolute',
                  right: '8px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  background: 'rgba(212, 165, 116, 0.2)',
                  border: '1px solid rgba(212, 165, 116, 0.3)',
                  borderRadius: '50%',
                  width: '36px',
                  height: '36px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  color: '#d4a574',
                  fontSize: '1rem',
                  animation: 'fadeIn 0.2s ease-out',
                }}
              >
                ↑
              </button>
            )}
          </div>
          
          <p style={{
            fontSize: '0.8125rem',
            color: 'rgba(163, 152, 138, 0.5)',
            marginTop: '20px',
            fontStyle: 'italic',
          }}>
            This will be the first color of your home
          </p>
        </div>
      )}
    </div>
  );
}
