import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import type { Room } from '../types';

interface RoomGeometryProps {
  room: Room;
}

export function RoomGeometry({ room }: RoomGeometryProps) {
  const groupRef = useRef<THREE.Group>(null);
  
  const roomWidth = 10;
  const roomDepth = 8;
  const roomHeight = 4;
  
  // Wall materials with smooth color transitions
  const wallMaterials = useMemo(() => {
    return {
      north: new THREE.MeshStandardMaterial({ 
        color: room.wallColors.north, 
        roughness: 0.9, 
        metalness: 0 
      }),
      south: new THREE.MeshStandardMaterial({ 
        color: room.wallColors.south, 
        roughness: 0.9, 
        metalness: 0 
      }),
      east: new THREE.MeshStandardMaterial({ 
        color: room.wallColors.east, 
        roughness: 0.9, 
        metalness: 0 
      }),
      west: new THREE.MeshStandardMaterial({ 
        color: room.wallColors.west, 
        roughness: 0.9, 
        metalness: 0 
      }),
      floor: new THREE.MeshStandardMaterial({ 
        color: '#8B6914', 
        roughness: 0.7, 
        metalness: 0.1 
      }),
    };
  }, [room.wallColors]);
  
  // Smooth color transitions
  useFrame(() => {
    const lerpSpeed = 0.03;
    wallMaterials.north.color.lerp(new THREE.Color(room.wallColors.north), lerpSpeed);
    wallMaterials.south.color.lerp(new THREE.Color(room.wallColors.south), lerpSpeed);
    wallMaterials.east.color.lerp(new THREE.Color(room.wallColors.east), lerpSpeed);
    wallMaterials.west.color.lerp(new THREE.Color(room.wallColors.west), lerpSpeed);
  });
  
  return (
    <group ref={groupRef}>
      {/* Floor */}
      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, 0, 0]} 
        receiveShadow
      >
        <planeGeometry args={[roomWidth, roomDepth]} />
        <primitive object={wallMaterials.floor} attach="material" />
      </mesh>
      
      {/* Ceiling (subtle, mostly invisible) */}
      <mesh 
        rotation={[Math.PI / 2, 0, 0]} 
        position={[0, roomHeight, 0]}
      >
        <planeGeometry args={[roomWidth, roomDepth]} />
        <meshStandardMaterial color="#2a2018" roughness={1} />
      </mesh>
      
      {/* North Wall (back) */}
      <mesh 
        position={[0, roomHeight / 2, -roomDepth / 2]} 
        receiveShadow
      >
        <planeGeometry args={[roomWidth, roomHeight]} />
        <primitive object={wallMaterials.north} attach="material" />
      </mesh>
      
      {/* South Wall (front, mostly invisible - camera side) */}
      <mesh 
        position={[0, roomHeight / 2, roomDepth / 2]} 
        rotation={[0, Math.PI, 0]}
      >
        <planeGeometry args={[roomWidth, roomHeight]} />
        <primitive object={wallMaterials.south} attach="material" />
      </mesh>
      
      {/* East Wall (right) */}
      <mesh 
        position={[roomWidth / 2, roomHeight / 2, 0]} 
        rotation={[0, -Math.PI / 2, 0]}
        receiveShadow
      >
        <planeGeometry args={[roomDepth, roomHeight]} />
        <primitive object={wallMaterials.east} attach="material" />
      </mesh>
      
      {/* West Wall (left) */}
      <mesh 
        position={[-roomWidth / 2, roomHeight / 2, 0]} 
        rotation={[0, Math.PI / 2, 0]}
        receiveShadow
      >
        <planeGeometry args={[roomDepth, roomHeight]} />
        <primitive object={wallMaterials.west} attach="material" />
      </mesh>
      
      {/* Baseboards */}
      <Baseboard width={roomWidth} depth={roomDepth} height={0.15} />
      
      {/* Subtle floor grid lines */}
      <FloorGrid width={roomWidth} depth={roomDepth} />
    </group>
  );
}

function Baseboard({ width, depth, height }: { width: number; depth: number; height: number }) {
  const baseColor = '#5c4033';
  
  return (
    <group>
      {/* North baseboard */}
      <mesh position={[0, height / 2, -depth / 2 + 0.02]}>
        <boxGeometry args={[width, height, 0.04]} />
        <meshStandardMaterial color={baseColor} roughness={0.8} />
      </mesh>
      {/* South baseboard */}
      <mesh position={[0, height / 2, depth / 2 - 0.02]}>
        <boxGeometry args={[width, height, 0.04]} />
        <meshStandardMaterial color={baseColor} roughness={0.8} />
      </mesh>
      {/* East baseboard */}
      <mesh position={[width / 2 - 0.02, height / 2, 0]}>
        <boxGeometry args={[0.04, height, depth]} />
        <meshStandardMaterial color={baseColor} roughness={0.8} />
      </mesh>
      {/* West baseboard */}
      <mesh position={[-width / 2 + 0.02, height / 2, 0]}>
        <boxGeometry args={[0.04, height, depth]} />
        <meshStandardMaterial color={baseColor} roughness={0.8} />
      </mesh>
    </group>
  );
}

function FloorGrid({ width, depth }: { width: number; depth: number }) {
  const lines = useMemo(() => {
    const points: THREE.Vector3[] = [];
    const divisions = 8;
    
    // Grid lines along depth
    for (let i = 0; i <= divisions; i++) {
      const x = -width / 2 + (width / divisions) * i;
      points.push(new THREE.Vector3(x, 0.01, -depth / 2));
      points.push(new THREE.Vector3(x, 0.01, depth / 2));
    }
    
    // Grid lines along width
    for (let i = 0; i <= divisions; i++) {
      const z = -depth / 2 + (depth / divisions) * i;
      points.push(new THREE.Vector3(-width / 2, 0.01, z));
      points.push(new THREE.Vector3(width / 2, 0.01, z));
    }
    
    return points;
  }, [width, depth]);
  
  const geometry = useMemo(() => {
    const geo = new THREE.BufferGeometry().setFromPoints(lines);
    return geo;
  }, [lines]);
  
  return (
    <lineSegments geometry={geometry}>
      <lineBasicMaterial color="#6b5b4f" transparent opacity={0.15} />
    </lineSegments>
  );
}
