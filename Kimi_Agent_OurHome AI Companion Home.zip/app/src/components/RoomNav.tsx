import { useStore } from '../store';
import { useState } from 'react';

export function RoomNav() {
  const rooms = useStore((s) => s.rooms);
  const currentRoomId = useStore((s) => s.currentRoomId);
  const setCurrentRoom = useStore((s) => s.setCurrentRoom);
  const [hoveredRoom, setHoveredRoom] = useState<string | null>(null);
  
  return (
    <div 
      style={{
        position: 'absolute',
        top: '24px',
        left: '50%',
        transform: 'translateX(-50%)',
        display: 'flex',
        gap: '8px',
        zIndex: 20,
        animation: 'fadeInDown 0.5s ease-out',
      }}
    >
      {rooms.map((room) => {
        const isActive = room.id === currentRoomId;
        const isHovered = room.id === hoveredRoom;
        const isUnlocked = room.unlocked;
        
        return (
          <button
            key={room.id}
            onClick={() => isUnlocked && setCurrentRoom(room.id)}
            onMouseEnter={() => setHoveredRoom(room.id)}
            onMouseLeave={() => setHoveredRoom(null)}
            style={{
              background: isActive 
                ? 'rgba(212, 165, 116, 0.2)' 
                : isHovered && isUnlocked
                  ? 'rgba(245, 240, 232, 0.1)'
                  : 'rgba(26, 20, 16, 0.7)',
              backdropFilter: 'blur(8px)',
              border: isActive 
                ? '1px solid rgba(212, 165, 116, 0.4)' 
                : '1px solid rgba(245, 240, 232, 0.1)',
              borderRadius: '9999px',
              padding: '8px 18px',
              color: isActive 
                ? '#f5f0e8' 
                : isUnlocked 
                  ? 'rgba(245, 240, 232, 0.6)' 
                  : 'rgba(245, 240, 232, 0.2)',
              fontSize: '0.8125rem',
              fontWeight: 400,
              cursor: isUnlocked ? 'pointer' : 'not-allowed',
              transition: 'all 0.25s ease',
              transform: isHovered && isUnlocked ? 'scale(1.05)' : 'scale(1)',
              whiteSpace: 'nowrap',
              letterSpacing: '0.01em',
            }}
          >
            {room.name}
            {!isUnlocked && (
              <span style={{
                marginLeft: '6px',
                fontSize: '0.6875rem',
                opacity: 0.5,
              }}>
                🔒
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
