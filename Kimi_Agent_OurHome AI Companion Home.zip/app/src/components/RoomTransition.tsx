import { useState, useEffect, useRef } from 'react';
import { useStore } from '../store';

export function RoomTransition() {
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [overlayColor, setOverlayColor] = useState('#1a1410');
  const currentRoomId = useStore((s) => s.currentRoomId);
  const rooms = useStore((s) => s.rooms);
  const prevRoomId = useRef(currentRoomId);
  
  useEffect(() => {
    if (prevRoomId.current !== currentRoomId) {
      // Start transition
      const room = rooms.find((r) => r.id === prevRoomId.current);
      const wallColor = room?.wallColors.north || '#1a1410';
      setOverlayColor(wallColor);
      setIsTransitioning(true);
      
      // Short delay then complete
      setTimeout(() => {
        setIsTransitioning(false);
      }, 500);
      
      prevRoomId.current = currentRoomId;
    }
  }, [currentRoomId, rooms]);
  
  return (
    <div
      className="room-transition-overlay"
      style={{
        background: overlayColor,
        opacity: isTransitioning ? 1 : 0,
        transition: isTransitioning 
          ? 'opacity 0.4s ease-in' 
          : 'opacity 0.6s ease-out',
      }}
    />
  );
}
