import { useRef, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { useStore } from '../store';
import * as THREE from 'three';
import { RoomGeometry } from './RoomGeometry';
import { MemoryObject3D } from './MemoryObject3D';
import { Furniture3D } from './Furniture3D';
import { DustParticles } from './DustParticles';
import { SceneLighting } from './SceneLighting';

export function Scene3D() {
  const currentRoomId = useStore((s) => s.currentRoomId);
  const rooms = useStore((s) => s.rooms);
  const memoryObjects = useStore((s) => s.memoryObjects);
  const timeOfDay = useStore((s) => s.timeOfDay);
  
  const currentRoom = rooms.find((r) => r.id === currentRoomId);
  const roomObjects = memoryObjects.filter((obj) => obj.roomId === currentRoomId);
  const roomFurniture = currentRoom?.furniture || [];
  
  // Smooth camera target for transitions
  const targetPosition = useMemo(() => {
    switch (currentRoomId) {
      case 'living_room': return new THREE.Vector3(5, 3.5, 5);
      case 'kitchen': return new THREE.Vector3(4, 3, 6);
      case 'study': return new THREE.Vector3(6, 3.5, 4);
      case 'bedroom': return new THREE.Vector3(4, 3, 5);
      case 'garden': return new THREE.Vector3(7, 4, 6);
      default: return new THREE.Vector3(5, 3.5, 5);
    }
  }, [currentRoomId]);
  
  const { camera } = useThree();
  const cameraRef = useRef(camera);
  cameraRef.current = camera;
  
  // Smooth camera animation
  useFrame((_, delta) => {
    const cam = cameraRef.current;
    cam.position.lerp(targetPosition, delta * 2);
    cam.lookAt(0, 1, 0);
  });
  
  return (
    <>
      <SceneLighting timeOfDay={timeOfDay} />
      
      <fog attach="fog" args={getFogArgs(timeOfDay)} />
      
      {/* Room shell */}
      {currentRoom && (
        <RoomGeometry
          key={currentRoomId}
          room={currentRoom}
        />
      )}
      
      {/* Furniture */}
      {roomFurniture.map((item) => (
        <Furniture3D key={item.id} item={item} />
      ))}
      
      {/* Memory objects */}
      {roomObjects.map((obj) => (
        <MemoryObject3D key={obj.id} obj={obj} />
      ))}
      
      {/* Ambient dust particles */}
      <DustParticles count={30} timeOfDay={timeOfDay} />
    </>
  );
}

function getFogArgs(timeOfDay: string): [string, number, number] {
  switch (timeOfDay) {
    case 'morning':
      return ['#FFF5E4', 8, 25];
    case 'afternoon':
      return ['#FFD580', 10, 30];
    case 'evening':
      return ['#FF9B6A', 6, 20];
    case 'night':
      return ['#1a1410', 5, 18];
    default:
      return ['#FFD580', 10, 30];
  }
}
