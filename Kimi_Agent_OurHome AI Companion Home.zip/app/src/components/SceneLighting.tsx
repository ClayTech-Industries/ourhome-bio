import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import type { TimeOfDay } from '../types';

interface SceneLightingProps {
  timeOfDay: TimeOfDay;
}

interface LightPreset {
  ambientColor: string;
  ambientIntensity: number;
  directionalColor: string;
  directionalIntensity: number;
  directionalPosition: [number, number, number];
  pointLightColor: string;
  pointLightIntensity: number;
  hemiColorTop: string;
  hemiColorBottom: string;
}

const LIGHT_PRESETS: Record<TimeOfDay, LightPreset> = {
  morning: {
    ambientColor: '#FFF5E4',
    ambientIntensity: 0.35,
    directionalColor: '#FFE4C4',
    directionalIntensity: 0.8,
    directionalPosition: [5, 8, 3],
    pointLightColor: '#FFE4C4',
    pointLightIntensity: 0,
    hemiColorTop: '#E8DCC8',
    hemiColorBottom: '#8B7355',
  },
  afternoon: {
    ambientColor: '#FFD580',
    ambientIntensity: 0.4,
    directionalColor: '#FFA500',
    directionalIntensity: 1.0,
    directionalPosition: [2, 10, 5],
    pointLightColor: '#FFA07A',
    pointLightIntensity: 0,
    hemiColorTop: '#FFE4B5',
    hemiColorBottom: '#C4A35A',
  },
  evening: {
    ambientColor: '#FF9B6A',
    ambientIntensity: 0.25,
    directionalColor: '#FF7F50',
    directionalIntensity: 0.6,
    directionalPosition: [-3, 4, 2],
    pointLightColor: '#FFA07A',
    pointLightIntensity: 0.5,
    hemiColorTop: '#E8A87C',
    hemiColorBottom: '#5C4033',
  },
  night: {
    ambientColor: '#2D3A5E',
    ambientIntensity: 0.15,
    directionalColor: '#4A5A8A',
    directionalIntensity: 0.3,
    directionalPosition: [-5, 8, -3],
    pointLightColor: '#FFD580',
    pointLightIntensity: 0.7,
    hemiColorTop: '#1a1a3e',
    hemiColorBottom: '#0D0D1A',
  },
};

export function SceneLighting({ timeOfDay }: SceneLightingProps) {
  const preset = LIGHT_PRESETS[timeOfDay];
  
  const ambientRef = useRef<THREE.AmbientLight>(null);
  const directionalRef = useRef<THREE.DirectionalLight>(null);
  const pointRef = useRef<THREE.PointLight>(null);
  const hemiRef = useRef<THREE.HemisphereLight>(null);
  
  // Target colors for smooth transitions
  const targets = useMemo(() => ({
    ambient: new THREE.Color(preset.ambientColor),
    directional: new THREE.Color(preset.directionalColor),
    point: new THREE.Color(preset.pointLightColor),
    hemiTop: new THREE.Color(preset.hemiColorTop),
    hemiBottom: new THREE.Color(preset.hemiColorBottom),
    dirPosition: new THREE.Vector3(...preset.directionalPosition),
  }), [preset]);
  
  // Smooth transitions
  useFrame(() => {
    const lerpSpeed = 0.02;
    
    if (ambientRef.current) {
      ambientRef.current.color.lerp(targets.ambient, lerpSpeed);
      ambientRef.current.intensity = THREE.MathUtils.lerp(
        ambientRef.current.intensity,
        preset.ambientIntensity,
        lerpSpeed
      );
    }
    
    if (directionalRef.current) {
      directionalRef.current.color.lerp(targets.directional, lerpSpeed);
      directionalRef.current.intensity = THREE.MathUtils.lerp(
        directionalRef.current.intensity,
        preset.directionalIntensity,
        lerpSpeed
      );
      directionalRef.current.position.lerp(targets.dirPosition, lerpSpeed);
    }
    
    if (pointRef.current) {
      pointRef.current.color.lerp(targets.point, lerpSpeed);
      pointRef.current.intensity = THREE.MathUtils.lerp(
        pointRef.current.intensity,
        preset.pointLightIntensity,
        lerpSpeed
      );
    }
    
    if (hemiRef.current) {
      hemiRef.current.color.lerp(targets.hemiTop, lerpSpeed);
      hemiRef.current.groundColor.lerp(targets.hemiBottom, lerpSpeed);
    }
  });
  
  return (
    <>
      {/* Hemisphere light for natural sky/ground color */}
      <hemisphereLight
        ref={hemiRef}
        color={preset.hemiColorTop}
        groundColor={preset.hemiColorBottom}
        intensity={0.4}
      />
      
      {/* Ambient light */}
      <ambientLight
        ref={ambientRef}
        color={preset.ambientColor}
        intensity={preset.ambientIntensity}
      />
      
      {/* Main directional light (sun/moon) */}
      <directionalLight
        ref={directionalRef}
        color={preset.directionalColor}
        intensity={preset.directionalIntensity}
        position={preset.directionalPosition}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-6}
        shadow-camera-right={6}
        shadow-camera-top={6}
        shadow-camera-bottom={-6}
        shadow-camera-near={0.5}
        shadow-camera-far={30}
        shadow-bias={-0.001}
      />
      
      {/* Interior point light (lamp glow) */}
      <pointLight
        ref={pointRef}
        color={preset.pointLightColor}
        intensity={preset.pointLightIntensity}
        position={[2, 2.5, 1]}
        distance={8}
        decay={2}
      />
      
      {/* Subtle rim light for depth */}
      <directionalLight
        color="#87CEEB"
        intensity={0.15}
        position={[-5, 3, -5]}
      />
    </>
  );
}
