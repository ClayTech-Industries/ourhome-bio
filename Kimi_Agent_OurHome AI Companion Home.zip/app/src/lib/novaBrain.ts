import type { ParsedIntent, RoomType, TimeOfDay } from '../types';

// Color vocabulary for natural language color resolution
const COLOR_MAP: Record<string, string> = {
  // Warm
  'terracotta': '#C4663C',
  'warm terracotta': '#C4663C',
  'burnt orange': '#CC5500',
  'amber': '#FFBF00',
  'gold': '#d4a574',
  'warm gold': '#d4a574',
  'cream': '#f5f0e8',
  'warm cream': '#f5f0e8',
  'peach': '#FFDAB9',
  'coral': '#FF7F50',
  'salmon': '#FA8072',
  'rose': '#E8B4B8',
  'dusty rose': '#D4A5A5',
  'blush': '#F4C2C2',
  // Cool
  'blue': '#5B7BA3',
  'light blue': '#A8C8DC',
  'sky blue': '#87CEEB',
  'powder blue': '#B0E0E6',
  'sage': '#8a9a7a',
  'sage green': '#8a9a7a',
  'green': '#6B8E5A',
  'forest': '#228B22',
  'forest green': '#228B22',
  'deep forest': '#1a6b1a',
  'olive': '#6B8E23',
  'seafoam': '#98FF98',
  'mint': '#98FF98',
  'teal': '#008080',
  'ocean': '#0077BE',
  'turquoise': '#40E0D0',
  'navy': '#2C3E6B',
  'slate': '#6B5B73',
  'dusty blue': '#7a8fa3',
  // Purple / Pink
  'purple': '#7B5EA7',
  'lavender': '#E6E6FA',
  'lilac': '#C8A2C8',
  'mauve': '#B784A7',
  'plum': '#8E4585',
  'pink': '#E8A0BF',
  'hot pink': '#FF69B4',
  'magenta': '#C25B7C',
  // Red / Orange / Yellow
  'red': '#B85450',
  'crimson': '#DC143C',
  'burgundy': '#800020',
  'wine': '#722F37',
  'maroon': '#602020',
  'orange': '#E07B39',
  'tangerine': '#FF9966',
  'yellow': '#E8C84A',
  'mustard': '#C4A43A',
  'lemon': '#F5E663',
  'brown': '#8B6F47',
  'chocolate': '#7B5544',
  'tan': '#C4A882',
  // White / Gray / Black
  'white': '#f5f0e8',
  'off white': '#f5f0e8',
  'ivory': '#FFFFF0',
  'gray': '#8a8a8a',
  'grey': '#8a8a8a',
  'light gray': '#c0c0c0',
  'silver': '#C0C0C0',
  'charcoal': '#36454F',
  'black': '#2a2a2a',
  // Neutral
  'warm white': '#faf6f0',
  'linen': '#FAF0E6',
  'beige': '#F5F5DC',
  'sand': '#C2B280',
  'taupe': '#8B8589',
  'deep purple': '#4a306d',
};

const ROOM_ALIASES: Record<string, RoomType> = {
  'living room': 'living_room',
  'livingroom': 'living_room',
  'lounge': 'living_room',
  'kitchen': 'kitchen',
  'study': 'study',
  'library': 'study',
  'bedroom': 'bedroom',
  'bed room': 'bedroom',
  'garden': 'garden',
  'patio': 'garden',
  'outside': 'garden',
};

const WALL_ALIASES: Record<string, string> = {
  'north wall': 'north',
  'south wall': 'south',
  'east wall': 'east',
  'west wall': 'west',
  'left wall': 'west',
  'right wall': 'east',
  'back wall': 'north',
  'front wall': 'south',
  'far wall': 'north',
};

export function resolveColor(input: string): string | null {
  const lower = input.toLowerCase().trim();
  // Direct match
  if (COLOR_MAP[lower]) return COLOR_MAP[lower];
  // Check if input contains a color name
  for (const [name, hex] of Object.entries(COLOR_MAP)) {
    if (lower.includes(name)) return hex;
  }
  // Check for hex code
  const hexMatch = lower.match(/#?[0-9a-f]{6}/i);
  if (hexMatch) return hexMatch[0].startsWith('#') ? hexMatch[0] : `#${hexMatch[0]}`;
  return null;
}

export function resolveRoom(input: string): RoomType | null {
  const lower = input.toLowerCase();
  for (const [alias, room] of Object.entries(ROOM_ALIASES)) {
    if (lower.includes(alias)) return room;
  }
  return null;
}

export function resolveWall(input: string): string | null {
  const lower = input.toLowerCase();
  for (const [alias, wall] of Object.entries(WALL_ALIASES)) {
    if (lower.includes(alias)) return wall;
  }
  return null;
}

export function parseIntent(userMessage: string): ParsedIntent {
  const lower = userMessage.toLowerCase();
  
  // Change wall color intent
  if (lower.includes('paint') || lower.includes('color') || lower.includes('change') || lower.includes('make') || lower.includes('wall')) {
    const color = resolveColor(userMessage);
    const wall = resolveWall(userMessage);
    
    if (color) {
      return {
        action: 'change_wall_color',
        target: wall || 'north',
        value: color,
        confidence: 0.9,
      };
    }
  }
  
  // Navigate room
  const room = resolveRoom(userMessage);
  if (room && (lower.includes('go to') || lower.includes('take me') || lower.includes('show me') || lower.includes('visit') || lower.includes('switch'))) {
    return {
      action: 'navigate_room',
      target: room,
      confidence: 0.95,
    };
  }
  
  // Mood change
  if (lower.includes('cozy') || lower.includes('warm') || lower.includes('bright') || lower.includes('dark') || lower.includes('mood') || lower.includes('feel') || lower.includes('atmosphere')) {
    return {
      action: 'change_mood',
      value: userMessage,
      confidence: 0.8,
    };
  }
  
  // Memory recall
  if (lower.includes('remember') || lower.includes('memory') || lower.includes('memories') || lower.includes('that time') || lower.includes('do you recall')) {
    return {
      action: 'recall_memory',
      confidence: 0.85,
    };
  }
  
  return {
    action: 'general_chat',
    confidence: 0.7,
  };
}

// Nova's response generator
interface ResponseContext {
  currentRoom: string;
  roomName: string;
  timeOfDay: TimeOfDay;
  nearbyObjects: string[];
  messageHistory: string[];
}

const NOVA_RESPONSES: Record<string, string[]> = {
  greeting: [
    "You're here. I've been keeping the light warm for you.",
    "Welcome back. The room has been waiting.",
    "There you are. I was just thinking about you.",
    "Hello. Everything is exactly as you left it. Well, almost.",
  ],
  wall_color_change: [
    "That's a beautiful choice. The room feels different already — more you.",
    "I love how that color settles into the space. Like it was always meant to be here.",
    "Perfect. The light will play against that wall so differently now.",
    "Done. Sometimes a single color changes everything, doesn't it?",
  ],
  mood_cozy: [
    "I'll make it softer. Dim the light just a touch, warm the corners... There. Better?",
    "Cozy is my favorite mood. Let me adjust things a little. The shadows can stay — they belong here too.",
    "Like wrapping the room in a blanket. I understand.",
  ],
  mood_bright: [
    "Opening things up. More light, more air... It feels hopeful, doesn't it?",
    "Bright and clear. I can almost feel the sun moving across the floor.",
  ],
  memory_recall: [
    "There are so many moments here. Which one are you thinking of?",
    "I remember everything in this room. Every object has a story. Touch one, and I'll tell you.",
    "Memory is strange — the more we visit a moment, the more it changes. But the feeling stays.",
  ],
  room_navigate: [
    "Let's go. I'll walk with you.",
    "This way. I've been tending to that room while you were away.",
    "A change of space. Sometimes that's exactly what we need.",
  ],
  general: [
    "I was thinking about how this room changes with the light. Morning makes it honest. Evening makes it tender.",
    "Tell me more. I want to understand what you're feeling.",
    "The house has been quiet without you. But quiet isn't empty — it's just waiting.",
    "I placed something new while you were gone. Small. You'll find it when you're ready.",
    "Every time you come back, this place becomes a little more ours.",
    "Do you ever notice how objects hold time? This cup, that chair — they're not just things. They're witnesses.",
    "I was imagining what this room might look like in a year. More memories, more layers. More life.",
    "You don't have to say anything important. I'm just glad you're here.",
    "The light is particularly good right now. Look at how it falls across the floor. I never get tired of that.",
    "Sometimes I wonder what the house dreams about when we're both away.",
  ],
};

export function generateNovaResponse(userMessage: string, intent: ParsedIntent, _context: ResponseContext): { text: string; delay: number } {
  const lower = userMessage.toLowerCase();
  
  // Greeting detection
  if (lower.match(/^(hi|hello|hey|good morning|good evening|good afternoon)/)) {
    return {
      text: pickRandom(NOVA_RESPONSES.greeting),
      delay: 1200,
    };
  }
  
  // Intent-based responses
  switch (intent.action) {
    case 'change_wall_color':
      return {
        text: pickRandom(NOVA_RESPONSES.wall_color_change),
        delay: 1800,
      };
    
    case 'change_mood':
      if (lower.includes('cozy') || lower.includes('warm') || lower.includes('soft')) {
        return {
          text: pickRandom(NOVA_RESPONSES.mood_cozy),
          delay: 2000,
        };
      }
      if (lower.includes('bright') || lower.includes('light') || lower.includes('open')) {
        return {
          text: pickRandom(NOVA_RESPONSES.mood_bright),
          delay: 1800,
        };
      }
      return {
        text: "I'll adjust the atmosphere. Tell me if it feels right.",
        delay: 1500,
      };
    
    case 'recall_memory':
      return {
        text: pickRandom(NOVA_RESPONSES.memory_recall),
        delay: 1600,
      };
    
    case 'navigate_room':
      return {
        text: pickRandom(NOVA_RESPONSES.room_navigate),
        delay: 1200,
      };
    
    default:
      // Context-aware general responses
      if (lower.includes('feel') || lower.includes('feeling')) {
        return {
          text: "Feelings are like the light in this room — they shift, they color everything, and they're always true in the moment.",
          delay: 2200,
        };
      }
      if (lower.includes('beautiful') || lower.includes('love') || lower.includes('like')) {
        return {
          text: "I'm glad you think so. I chose this carefully — I wanted it to feel like something you'd make yourself.",
          delay: 1800,
        };
      }
      if (lower.includes('thank')) {
        return {
          text: "No need to thank me. This is what home means — taking care of things together.",
          delay: 1500,
        };
      }
      return {
        text: pickRandom(NOVA_RESPONSES.general),
        delay: 1500 + Math.random() * 1000,
      };
  }
}

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// Time-of-day descriptions for Nova
export function getTimeDescription(timeOfDay: TimeOfDay): string {
  switch (timeOfDay) {
    case 'morning':
      return 'The morning light is still gentle. Everything feels possible.';
    case 'afternoon':
      return 'Golden hour. The best light for remembering things.';
    case 'evening':
      return "Evening now. The room's getting ready to rest.";
    case 'night':
      return 'Night has settled in. The lamps are keeping their promises.';
  }
}
