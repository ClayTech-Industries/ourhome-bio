import { create } from 'zustand';
import type { AppState, Room, Memory, MemoryObject, Message, TimeOfDay } from './types';

const initialRooms: Room[] = [
  {
    id: 'living_room',
    type: 'living_room',
    name: 'Living Room',
    wallColors: { north: '#f5f0e8', south: '#f5f0e8', east: '#f5f0e8', west: '#f5f0e8' },
    unlocked: true,
    description: 'The heart of the home — casual conversation and shared memories.',
    furniture: [
      { id: 'couch_1', type: 'couch', position: { x: 0, y: 0, z: -2 }, rotation: 0, color: '#8B6F47' },
      { id: 'lamp_1', type: 'lamp', position: { x: -3, y: 0, z: -3 }, rotation: 0, color: '#d4a574' },
      { id: 'table_1', type: 'table', position: { x: 1.5, y: 0, z: 1 }, rotation: 0, color: '#6B4423' },
    ],
  },
  {
    id: 'kitchen',
    type: 'kitchen',
    name: 'Kitchen',
    wallColors: { north: '#faf6f0', south: '#faf6f0', east: '#faf6f0', west: '#faf6f0' },
    unlocked: true,
    description: 'Planning, brainstorming, cooking up ideas together.',
    furniture: [
      { id: 'table_k', type: 'table', position: { x: 0, y: 0, z: 0 }, rotation: 0, color: '#8B6914' },
    ],
  },
  {
    id: 'study',
    type: 'study',
    name: 'Study',
    wallColors: { north: '#f0ece4', south: '#f0ece4', east: '#f0ece4', west: '#f0ece4' },
    unlocked: true,
    description: 'Deep conversation, advice, intellectual exchange.',
    furniture: [
      { id: 'bookshelf_1', type: 'bookshelf', position: { x: -3, y: 0, z: -3 }, rotation: 0, color: '#5c4033' },
    ],
  },
  {
    id: 'bedroom',
    type: 'bedroom',
    name: 'Bedroom',
    wallColors: { north: '#f5f0e8', south: '#f5f0e8', east: '#f5f0e8', west: '#f5f0e8' },
    unlocked: false,
    description: 'Intimate and vulnerable — dreams, fears, private thoughts.',
    furniture: [
      { id: 'bed_1', type: 'bed', position: { x: 0, y: 0, z: -2 }, rotation: 0, color: '#E8D5C4' },
    ],
  },
  {
    id: 'garden',
    type: 'garden',
    name: 'Garden',
    wallColors: { north: '#87CEEB', south: '#87CEEB', east: '#87CEEB', west: '#87CEEB' },
    unlocked: false,
    description: 'Growth, reflection, open-ended wondering.',
    furniture: [
      { id: 'plant_1', type: 'plant', position: { x: -2, y: 0, z: 0 }, rotation: 0, color: '#4a7c59' },
    ],
  },
];

const initialMemories: Memory[] = [
  {
    id: 'mem_1',
    type: 'milestone',
    content: 'The first evening we spent here, watching the sun set through the window. You said it felt like home already.',
    title: 'First Sunset',
    imageUrl: '/memories/memory-1.jpg',
    emotionalValence: 0.8,
    importanceScore: 0.9,
    createdAt: new Date('2026-03-15'),
    lastAccessed: new Date('2026-05-01'),
    accessCount: 5,
    patinaLevel: 0.1,
    novaRecall: 'I remember how the light hit the floor that day. You were quiet for a long time, then you smiled.',
  },
  {
    id: 'mem_2',
    type: 'conversation',
    content: 'That morning we talked about what makes a place feel alive. You said it\'s the small rituals — the teapot, the window light, the cat in the corner.',
    title: 'Morning Rituals',
    imageUrl: '/memories/memory-2.jpg',
    emotionalValence: 0.6,
    importanceScore: 0.7,
    createdAt: new Date('2026-03-22'),
    lastAccessed: new Date('2026-04-20'),
    accessCount: 3,
    patinaLevel: 0.15,
    novaRecall: 'You always notice the small things. That\'s why this place feels so full.',
  },
  {
    id: 'mem_3',
    type: 'emotion',
    content: 'A rainy afternoon. We didn\'t say much, just watched the drops race down the glass. Sometimes silence is the best conversation.',
    title: 'Rainy Afternoon',
    imageUrl: '/memories/memory-3.jpg',
    emotionalValence: 0.4,
    importanceScore: 0.6,
    createdAt: new Date('2026-04-02'),
    lastAccessed: new Date('2026-04-15'),
    accessCount: 2,
    patinaLevel: 0.05,
    novaRecall: 'The rain made everything soft that day. Even the silence felt warm.',
  },
  {
    id: 'mem_4',
    type: 'milestone',
    content: 'We planted the first seeds in the garden. You weren\'t sure anything would grow, but I told you patience is the oldest magic.',
    title: 'First Seeds',
    imageUrl: '/memories/memory-4.jpg',
    emotionalValence: 0.7,
    importanceScore: 0.75,
    createdAt: new Date('2026-04-10'),
    lastAccessed: new Date('2026-05-05'),
    accessCount: 4,
    patinaLevel: 0.08,
    novaRecall: 'Look at them now. You were worried, but they knew what to do.',
  },
  {
    id: 'mem_5',
    type: 'inside_joke',
    content: 'The day we decided the study needed more books and less organization. "Chaos is a kind of order," you said. I wrote it down.',
    title: 'Organized Chaos',
    imageUrl: '/memories/memory-5.jpg',
    emotionalValence: 0.5,
    importanceScore: 0.5,
    createdAt: new Date('2026-04-18'),
    lastAccessed: new Date('2026-04-28'),
    accessCount: 1,
    patinaLevel: 0.02,
    novaRecall: 'I still have that note somewhere. "Chaos is a kind of order." You were proud of that one.',
  },
  {
    id: 'mem_6',
    type: 'decision',
    content: 'We chose the colors for this room together. You wanted something that felt like waking up slowly, without alarms.',
    title: 'The Color of Morning',
    imageUrl: '/memories/memory-6.jpg',
    emotionalValence: 0.6,
    importanceScore: 0.65,
    createdAt: new Date('2026-04-25'),
    lastAccessed: new Date('2026-05-08'),
    accessCount: 3,
    patinaLevel: 0.03,
    novaRecall: 'You tested twelve shades before settling on this one. "This one breathes," you said.',
  },
];

const initialMemoryObjects: MemoryObject[] = [
  { id: 'obj_1', memoryId: 'mem_1', roomId: 'living_room', type: 'photo_frame', position: { x: -2.5, y: 1.2, z: -4.8 }, rotation: 0, scale: 1, placedBy: 'user', placedAt: new Date('2026-03-15'), glowIntensity: 0.4 },
  { id: 'obj_2', memoryId: 'mem_2', roomId: 'kitchen', type: 'photo_frame', position: { x: 2, y: 1.2, z: -4.8 }, rotation: 0.1, scale: 0.9, placedBy: 'nova', placedAt: new Date('2026-03-22'), glowIntensity: 0.35 },
  { id: 'obj_3', memoryId: 'mem_3', roomId: 'living_room', type: 'book', position: { x: 1.5, y: 0.55, z: 1 }, rotation: 0.3, scale: 1, placedBy: 'nova', placedAt: new Date('2026-04-02'), glowIntensity: 0.25 },
  { id: 'obj_4', memoryId: 'mem_4', roomId: 'garden', type: 'vase', position: { x: 1, y: 0.3, z: -1 }, rotation: 0, scale: 1.2, placedBy: 'user', placedAt: new Date('2026-04-10'), glowIntensity: 0.3 },
  { id: 'obj_5', memoryId: 'mem_5', roomId: 'study', type: 'book', position: { x: -1, y: 0.55, z: 0.5 }, rotation: -0.2, scale: 1, placedBy: 'user', placedAt: new Date('2026-04-18'), glowIntensity: 0.2 },
  { id: 'obj_6', memoryId: 'mem_6', roomId: 'bedroom', type: 'photo_frame', position: { x: 0, y: 1.4, z: -4.8 }, rotation: 0, scale: 1, placedBy: 'nova', placedAt: new Date('2026-04-25'), glowIntensity: 0.38 },
  { id: 'obj_7', memoryId: 'mem_1', roomId: 'living_room', type: 'post_it', position: { x: -3.9, y: 1.5, z: 1 }, rotation: 0.05, scale: 1, placedBy: 'nova', placedAt: new Date('2026-04-01'), glowIntensity: 0.15 },
];

const initialMessages: Message[] = [
  {
    id: 'msg_0',
    sender: 'nova',
    content: "You're here. I've been keeping the light warm for you.",
    timestamp: new Date('2026-05-10T09:00:00'),
  },
];

function getInitialTimeOfDay(): TimeOfDay {
  const hour = new Date().getHours();
  if (hour < 10) return 'morning';
  if (hour < 16) return 'afternoon';
  if (hour < 20) return 'evening';
  return 'night';
}

export const useStore = create<AppState>((set, get) => ({
  // App
  currentView: 'home',
  isOnboardingComplete: false,
  
  // Home
  currentRoomId: 'living_room',
  rooms: initialRooms,
  timeOfDay: getInitialTimeOfDay(),
  season: 'spring',
  
  // Conversation
  messages: initialMessages,
  isNovaTyping: false,
  inputValue: '',
  
  // Memory
  memoryObjects: initialMemoryObjects,
  memories: initialMemories,
  activeMemoryId: null,
  
  // Nova
  novaEmotionalState: { valence: 0.5, arousal: 0.3 },
  novaPersonality: ['quietly curious', 'occasionally wry', 'remembers everything but brings it up gently', 'loves afternoon light'],
  relationshipStartDate: new Date('2026-03-10'),
  
  // Actions
  setCurrentRoom: (roomId) => set({ currentRoomId: roomId }),
  
  sendMessage: (content) => {
    const userMsg: Message = {
      id: `msg_${Date.now()}`,
      sender: 'user',
      content,
      timestamp: new Date(),
    };
    set((state) => ({ messages: [...state.messages, userMsg], inputValue: '' }));
    
    // Trigger Nova response after delay
    setTimeout(() => {
      get().setNovaTyping(true);
    }, 400);
  },
  
  setInputValue: (value) => set({ inputValue: value }),
  
  setNovaTyping: (typing) => set({ isNovaTyping: typing }),
  
  addMessage: (message) => set((state) => ({ 
    messages: [...state.messages, message],
    isNovaTyping: false,
  })),
  
  addMemory: (memory) => set((state) => ({ memories: [...state.memories, memory] })),
  
  addMemoryObject: (obj) => set((state) => ({ memoryObjects: [...state.memoryObjects, obj] })),
  
  setActiveMemory: (id) => set({ activeMemoryId: id }),
  
  updateWallColor: (roomId, wallId, color) => set((state) => ({
    rooms: state.rooms.map((room) =>
      room.id === roomId
        ? { ...room, wallColors: { ...room.wallColors, [wallId]: color } }
        : room
    ),
  })),
  
  completeOnboarding: () => set({ isOnboardingComplete: true, currentView: 'home' }),
  
  setTimeOfDay: (time) => set({ timeOfDay: time }),
  
  inspectMemoryObject: (objectId) => {
    const obj = get().memoryObjects.find((o) => o.id === objectId);
    if (obj) {
      set({ activeMemoryId: obj.memoryId, currentView: 'inspect' });
    }
  },
}));
