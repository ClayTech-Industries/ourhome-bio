// OurHome — Type Definitions

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export type RoomType = 'living_room' | 'kitchen' | 'study' | 'bedroom' | 'garden';

export interface Room {
  id: string;
  type: RoomType;
  name: string;
  wallColors: {
    north: string;
    south: string;
    east: string;
    west: string;
  };
  unlocked: boolean;
  description: string;
  furniture: FurnitureItem[];
}

export interface FurnitureItem {
  id: string;
  type: 'couch' | 'table' | 'lamp' | 'bookshelf' | 'bed' | 'plant';
  position: Vec3;
  rotation: number;
  color: string;
}

export type MemoryType = 'conversation' | 'milestone' | 'inside_joke' | 'decision' | 'emotion';

export interface Memory {
  id: string;
  type: MemoryType;
  content: string;
  title: string;
  imageUrl?: string;
  emotionalValence: number;
  importanceScore: number;
  createdAt: Date;
  lastAccessed: Date;
  accessCount: number;
  patinaLevel: number;
  novaRecall: string;
}

export interface MemoryObject {
  id: string;
  memoryId: string;
  roomId: string;
  type: 'photo_frame' | 'book' | 'post_it' | 'vase' | 'souvenir';
  position: Vec3;
  rotation: number;
  scale: number;
  placedBy: 'user' | 'nova' | 'system';
  placedAt: Date;
  glowIntensity: number;
}

export type TimeOfDay = 'morning' | 'afternoon' | 'evening' | 'night';
export type Season = 'spring' | 'summer' | 'autumn' | 'winter';

export interface NovaEmotionalState {
  valence: number;
  arousal: number;
}

export interface Message {
  id: string;
  sender: 'user' | 'nova';
  content: string;
  timestamp: Date;
  triggeredChange?: EnvironmentChange;
}

export interface EnvironmentChange {
  type: 'wall_color' | 'object_added' | 'object_moved' | 'lighting_changed';
  roomId: string;
  description: string;
  wallId?: string;
  color?: string;
  objectId?: string;
}

export interface AppState {
  // App
  currentView: 'home' | 'onboarding' | 'inspect';
  isOnboardingComplete: boolean;
  
  // Home
  currentRoomId: string;
  rooms: Room[];
  timeOfDay: TimeOfDay;
  season: Season;
  
  // Conversation
  messages: Message[];
  isNovaTyping: boolean;
  inputValue: string;
  
  // Memory
  memoryObjects: MemoryObject[];
  memories: Memory[];
  activeMemoryId: string | null;
  
  // Nova
  novaEmotionalState: NovaEmotionalState;
  novaPersonality: string[];
  relationshipStartDate: Date;
  
  // Actions
  setCurrentRoom: (roomId: string) => void;
  sendMessage: (content: string) => void;
  setInputValue: (value: string) => void;
  setNovaTyping: (typing: boolean) => void;
  addMessage: (message: Message) => void;
  addMemory: (memory: Memory) => void;
  addMemoryObject: (obj: MemoryObject) => void;
  setActiveMemory: (id: string | null) => void;
  updateWallColor: (roomId: string, wallId: string, color: string) => void;
  completeOnboarding: () => void;
  setTimeOfDay: (time: TimeOfDay) => void;
  inspectMemoryObject: (objectId: string) => void;
}

export interface ParsedIntent {
  action: 'change_wall_color' | 'add_object' | 'change_mood' | 'recall_memory' | 'navigate_room' | 'general_chat';
  target?: string;
  value?: string;
  confidence: number;
  responsePrompt?: string;
}
